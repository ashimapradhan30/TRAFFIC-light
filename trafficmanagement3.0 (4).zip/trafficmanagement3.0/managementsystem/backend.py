import threading
import time
import logging
from datetime import datetime

# Configure logging for ambulance priority tracking
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

class TrafficLightController:
    def __init__(self, update_gui_callback):
        self.state = 'vehicle_green'
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.ambulance_priority = False
        self.pedestrian_requested = False
        self.update_gui_callback = update_gui_callback
        logger.info("TrafficLightController initialized")

    def run(self):
        # Main loop: do not hold the lock while sleeping/waiting so other threads
        # (e.g. trigger_ambulance) can set flags immediately.
        logger.info("Controller started")
        while not self.stop_event.is_set():
            # Check ambulance first (highest priority - can interrupt anything)
            with self.lock:
                ambulance_active = self.ambulance_priority
            
            if ambulance_active:
                logger.warning("🚑 AMBULANCE PRIORITY TRIGGERED - Overriding current cycle")
                self._prioritize_ambulance()
            elif self.pedestrian_requested and self.state == 'vehicle_green':
                # consume the pedestrian request under lock, then perform timed steps
                with self.lock:
                    self.pedestrian_requested = False
                logger.info("🚶 Pedestrian crossing initiated")
                # Pedestrian crossing: green -> yellow -> red -> pedestrian green -> back to green
                self._switch_state('vehicle_yellow')
                self._delay_and_update(2)
                self._switch_state('vehicle_red')
                self._delay_and_update(1)
                self._switch_state('pedestrian_green')
                self._delay_and_update(5)
                self._switch_state('vehicle_green')
            else:
                self._normal_cycle()

            # Use wait so we can be interrupted quickly by stop_event
            self.stop_event.wait(0.1)

    def _normal_cycle(self):
        if self.state == 'vehicle_green':
            self._delay_and_update(5)
            self._switch_state('vehicle_yellow')
            self._delay_and_update(2)
            self._switch_state('vehicle_red')
            self._delay_and_update(1)
            self._switch_state('vehicle_green')
        else:
            logger.debug("Resetting to vehicle_green")
            self._switch_state('vehicle_green')

    def _prioritize_ambulance(self):
        # Ambulance priority works like pedestrian crossing
        # It transitions through yellow and red first, then gets extended green time
        logger.info("🚑 Ambulance detected - transitioning lights")
        
        # First: transition to yellow (regardless of current state)
        if self.state != 'vehicle_yellow':
            self._switch_state('vehicle_yellow')
            self._delay_and_update(2)
        
        # Second: transition to red
        if self.state != 'vehicle_red':
            self._switch_state('vehicle_red')
            self._delay_and_update(1)
        
        # Third: give ambulance extended green time
        logger.info("🚑 Granting ambulance green light for 8 seconds")
        self._switch_state('vehicle_green')
        self._delay_and_update(8)
        
        # Reset the priority flag
        with self.lock:
            self.ambulance_priority = False
            self.pedestrian_requested = False  # Clear any pending pedestrian requests
        
        logger.info("🚑 Ambulance sequence complete, returning to normal")

    def _switch_state(self, next_state):
        # Protect state mutation but call GUI update outside the lock to avoid
        # blocking other operations.
        with self.lock:
            self.state = next_state
        try:
            self.update_gui_callback(self.state)
        except Exception as e:
            # Don't let GUI callback exceptions break the controller loop
            logger.error(f"GUI callback error: {e}")
            pass

    def _delay_and_update(self, seconds):
        # Wait in 1-second increments, but check for ambulance_priority and stop_event
        # This allows ambulance to interrupt delays within 1 second
        for i in range(seconds):
            # Check if ambulance was triggered (highest priority interrupt)
            with self.lock:
                if self.ambulance_priority:
                    logger.debug(f"🚑 Ambulance override: breaking out of {seconds}s delay at {i}s elapsed")
                    return  # Exit immediately to handle ambulance
            
            # Check if stop event was set
            if self.stop_event.is_set():
                break
            
            # Wait up to 1 second or until stop_event; this makes sleeping interruptible
            self.stop_event.wait(1)

    def request_pedestrian(self):
        with self.lock:
            self.pedestrian_requested = True
        logger.info("Pedestrian request received")

    def trigger_ambulance(self):
        with self.lock:
            self.ambulance_priority = True
            # Also clear pedestrian request since ambulance takes precedence
            self.pedestrian_requested = False
        logger.warning("🚑 AMBULANCE TRIGGER ACTIVATED - HIGH PRIORITY")

    def stop(self):
        logger.info("Stopping controller")
        self.stop_event.set()
