"""
Traffic Management System v3.0 - Main Entry Point
Supports both 2D Tkinter GUI and 3D Pygame/OpenGL Animation
"""

import threading
import tkinter as tk
from tkinter import ttk, messagebox
import logging
import sys
import os
import argparse

from backend import TrafficLightController
from frontend import TrafficLightGUI

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)


class LauncherWindow:
    """Mode selector window for 2D or 3D animation"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("🚦 Traffic Management System v3.0 - Launcher")
        self.root.geometry("600x400")
        self.root.resizable(False, False)
        self.root.configure(bg="#f0f0f0")
        
        self.controller = None
        self.selected_mode = tk.StringVar(value="2d")
        
        self._create_ui()
        self._center_window()
    
    def _center_window(self):
        """Center the window on screen"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f"{width}x{height}+{x}+{y}")
    
    def _create_ui(self):
        """Create the launcher UI"""
        # Title
        title_frame = tk.Frame(self.root, bg="#2c3e50")
        title_frame.pack(fill=tk.X, padx=0, pady=0)
        
        title_label = tk.Label(
            title_frame,
            text="🚦 Traffic Light Management System",
            font=("Arial", 24, "bold"),
            fg="white",
            bg="#2c3e50",
            pady=20
        )
        title_label.pack()
        
        # Subtitle
        subtitle = tk.Label(
            self.root,
            text="Select Animation Mode",
            font=("Arial", 14, "bold"),
            bg="#f0f0f0"
        )
        subtitle.pack(pady=20)
        
        # Mode selection frame
        mode_frame = tk.Frame(self.root, bg="#f0f0f0")
        mode_frame.pack(fill=tk.BOTH, expand=True, padx=40, pady=20)
        
        # 2D Mode option
        mode_2d_frame = tk.Frame(mode_frame, bg="white", relief=tk.RIDGE, bd=2)
        mode_2d_frame.pack(fill=tk.X, pady=15)
        
        rb_2d = tk.Radiobutton(
            mode_2d_frame,
            text="2D Tkinter Animation",
            variable=self.selected_mode,
            value="2d",
            font=("Arial", 12),
            bg="white",
            fg="#2c3e50"
        )
        rb_2d.pack(anchor=tk.W, padx=20, pady=15)
        
        desc_2d = tk.Label(
            mode_2d_frame,
            text="• Multi-directional intersection view\n• 12 vehicles + 3 ambulances\n• Pedestrian signals with state tracking\n• Real-time timing display",
            font=("Arial", 10),
            bg="white",
            fg="#555555",
            justify=tk.LEFT
        )
        desc_2d.pack(anchor=tk.W, padx=40, pady=(0, 15))
        
        # 3D Mode option
        mode_3d_frame = tk.Frame(mode_frame, bg="white", relief=tk.RIDGE, bd=2)
        mode_3d_frame.pack(fill=tk.X, pady=15)
        
        rb_3d = tk.Radiobutton(
            mode_3d_frame,
            text="3D Cartoon Animation (Experimental)",
            variable=self.selected_mode,
            value="3d",
            font=("Arial", 12, "bold"),
            bg="white",
            fg="#e74c3c"
        )
        rb_3d.pack(anchor=tk.W, padx=20, pady=15)
        
        desc_3d = tk.Label(
            mode_3d_frame,
            text="• 3D cartoon-style traffic lights\n• Rotating camera with smooth transitions\n• Emergency vehicle flashing effects\n• Pedestrian signals with 3D rendering\n• Realistic lighting and shadows",
            font=("Arial", 10),
            bg="white",
            fg="#555555",
            justify=tk.LEFT
        )
        desc_3d.pack(anchor=tk.W, padx=40, pady=(0, 15))
        
        # Button frame
        button_frame = tk.Frame(self.root, bg="#f0f0f0")
        button_frame.pack(fill=tk.X, padx=40, pady=20)
        
        launch_btn = tk.Button(
            button_frame,
            text="▶ Launch Selected Mode",
            font=("Arial", 12, "bold"),
            bg="#27ae60",
            fg="white",
            padx=20,
            pady=10,
            command=self.launch_animation
        )
        launch_btn.pack(side=tk.LEFT, padx=5)
        
        exit_btn = tk.Button(
            button_frame,
            text="Exit",
            font=("Arial", 12),
            bg="#e74c3c",
            fg="white",
            padx=20,
            pady=10,
            command=self.root.quit
        )
        exit_btn.pack(side=tk.LEFT, padx=5)
    
    def launch_animation(self):
        """Launch selected animation mode"""
        mode = self.selected_mode.get()
        print(f"DEBUG: launch_animation called with mode: {mode}")
        logger.info(f"Launch button clicked - Mode: {mode}")
        
        try:
            logger.info(f"Starting Traffic Management System in {mode.upper()} mode")
            print(f"DEBUG: Initializing controller...")
            
            # Initialize controller
            self.controller = TrafficLightController(lambda state: None)
            print(f"DEBUG: Controller initialized")
            
            if mode == "2d":
                print(f"DEBUG: Launching 2D mode...")
                self._launch_2d_mode()
            elif mode == "3d":
                print(f"DEBUG: Launching 3D mode...")
                self._launch_3d_mode()
            else:
                print(f"DEBUG: Unknown mode: {mode}")
            
        except Exception as e:
            print(f"DEBUG: Exception in launch_animation: {e}")
            logger.error(f"Error launching {mode} mode: {e}", exc_info=True)
            messagebox.showerror("Error", f"Failed to launch {mode} mode:\n{str(e)}")
    
    def _launch_2d_mode(self):
        """Launch 2D Tkinter animation"""
        try:
            # Close launcher
            self.root.withdraw()
            
            # Create new window for 2D GUI
            gui_root = tk.Tk()
            app = TrafficLightGUI(gui_root, self.controller)
            self.controller.update_gui_callback = app.update_gui
            
            # Start controller thread
            controller_thread = threading.Thread(
                target=self.controller.run,
                name="ControllerThread",
                daemon=True
            )
            controller_thread.start()
            logger.info("2D GUI launched and controller started")
            
            gui_root.mainloop()
            
        except Exception as e:
            logger.error(f"Error in 2D mode: {e}", exc_info=True)
            messagebox.showerror("Error", f"Error in 2D mode:\n{str(e)}")
            self.root.deiconify()
    
    def _launch_3d_mode(self):
        """Launch 3D Pygame animation"""
        try:
            # Check dependencies
            try:
                import pygame
                from OpenGL.GL import glClear
            except ImportError as e:
                messagebox.showerror(
                    "Missing Dependencies",
                    f"3D animation requires:\n- pygame\n- PyOpenGL\n\nPlease install: pip install pygame PyOpenGL"
                )
                logger.error(f"Missing dependencies for 3D: {e}")
                return
            
            # Import 3D animation module
            from animation_3d_render import Animation3D
            
            # Start controller thread
            controller_thread = threading.Thread(
                target=self.controller.run,
                name="ControllerThread",
                daemon=True
            )
            controller_thread.start()
            logger.info("3D animation launched and controller started")
            
            # Close launcher and run 3D animation
            self.root.withdraw()
            animation = Animation3D(self.controller, width=1200, height=800)
            animation.run()
            
        except ImportError as e:
            logger.error(f"Missing 3D dependencies: {e}")
            messagebox.showerror(
                "Missing Dependencies",
                "3D animation requires pygame and PyOpenGL.\n\n"
                "Install with:\npip install pygame PyOpenGL PyOpenGL_accelerate"
            )
        except Exception as e:
            logger.error(f"Error in 3D mode: {e}", exc_info=True)
            messagebox.showerror("Error", f"Error in 3D mode:\n{str(e)}")
            self.root.deiconify()


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Traffic Management System v3.0")
    parser.add_argument('--mode', choices=['2d', '3d'], help='Force animation mode')
    parser.add_argument('--log-file', help='Optional log file path')
    args = parser.parse_args()

    # Optional file logging
    if args.log_file:
        fh = logging.FileHandler(args.log_file)
        fh.setLevel(logging.INFO)
        fh.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%H:%M:%S'))
        logger.addHandler(fh)

    logger.info("Starting Traffic Management System v3.0")

    # Helper: attempt to start 3D; returns True on success
    def try_launch_3d(controller, root_window=None):
        try:
            print("Checking for 3D dependencies (pygame, OpenGL)...")
            import pygame
            from OpenGL import GL  # noqa: F401
        except Exception as e:
            logger.debug(f"3D dependency check failed: {e}")
            return False

        try:
            from animation_3d_render import Animation3D
        except Exception as e:
            logger.error(f"Failed to import 3D animation module: {e}", exc_info=True)
            return False

        try:
            # Start controller thread
            controller_thread = threading.Thread(target=controller.run, name="ControllerThread", daemon=True)
            controller_thread.start()
            logger.info("Controller thread started for 3D mode")

            # Hide Tk window if provided
            if root_window:
                root_window.withdraw()

            print("Launching 3D Pygame/OpenGL animation...")
            animation = Animation3D(controller, width=1200, height=800)
            animation.run()
            return True
        except Exception as e:
            logger.error(f"Error while running 3D animation: {e}", exc_info=True)
            try:
                import pygame
                pygame.quit()
            except Exception:
                pass
            return False

    # Initialize controller (shared)
    controller = TrafficLightController(lambda state: None)

    # Create a Tk root for any UI messages; we'll hide it if running 3D
    root = tk.Tk()

    # If mode forced to 2d, skip 3D attempts
    if args.mode == '2d':
        logger.info("Mode forced to 2D via CLI")
        app = TrafficLightGUI(root, controller)
        controller.update_gui_callback = app.update_gui
        controller_thread = threading.Thread(target=controller.run, name="ControllerThread", daemon=True)
        controller_thread.start()
        root.mainloop()
        return

    # If mode forced to 3d, try 3D and show error if it fails
    if args.mode == '3d':
        success = try_launch_3d(controller, root_window=root)
        if not success:
            messagebox.showerror("3D Error", "Failed to start 3D animation. Check dependencies and logs.")
        return

    # No mode forced: prefer 3D, fall back to 2D
    if try_launch_3d(controller, root_window=root):
        logger.info("Exited 3D animation cleanly")
        return

    logger.warning("3D mode unavailable or failed; falling back to 2D")
    root.deiconify()
    try:
        app = TrafficLightGUI(root, controller)
        controller.update_gui_callback = app.update_gui
        controller_thread = threading.Thread(target=controller.run, name="ControllerThread", daemon=True)
        controller_thread.start()
        root.mainloop()
    except Exception as e:
        logger.error(f"Error launching 2D GUI: {e}", exc_info=True)
        messagebox.showerror("Error", f"Error launching 2D mode:\n{str(e)}")


if __name__ == "__main__":
    main()
