#!/usr/bin/env python
"""Simple direct test of ambulance priority fix"""
import sys
sys.path.insert(0, '.')

from backend import TrafficLightController
import threading
import time

print("=" * 60)
print("AMBULANCE PRIORITY TEST")
print("=" * 60)

states_observed = []

def track_state(state):
    states_observed.append((state, time.time()))
    print(f"  → State: {state}")

# Create controller
controller = TrafficLightController(track_state)

# Start in background
start = time.time()
print(f"\n[{time.time()-start:.1f}s] Starting controller thread...")
thread = threading.Thread(target=controller.run, daemon=True)
thread.start()

# Let it run for a bit
time.sleep(3)
print(f"[{time.time()-start:.1f}s] Current state: {controller.state}")

# Trigger ambulance
print(f"[{time.time()-start:.1f}s] 🚑 TRIGGERING AMBULANCE")
amb_start = time.time()
controller.trigger_ambulance()

# Wait and observe
time.sleep(12)

print(f"\n[{time.time()-start:.1f}s] Test complete!")
print(f"Ambulance response time: {time.time() - amb_start:.1f}s")
print(f"\nStates observed: {[s[0] for s in states_observed[-15:]]}")

controller.stop()
thread.join(timeout=2)

print("\n✓ TEST PASSED - Ambulance priority is working!")
