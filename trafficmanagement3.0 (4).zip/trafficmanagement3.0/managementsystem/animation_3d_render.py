"""
3D Cartoon-Style Traffic Light Animation System
Uses Pygame with 3D graphics to create a visually appealing traffic light simulation
"""

import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import threading
import time
import logging
import os
from collections import deque
import random

logger = logging.getLogger(__name__)


class Vector3:
    """3D Vector for math operations"""
    def __init__(self, x=0, y=0, z=0):
        self.x = x
        self.y = y
        self.z = z
    
    def __add__(self, other):
        return Vector3(self.x + other.x, self.y + other.y, self.z + other.z)
    
    def __sub__(self, other):
        return Vector3(self.x - other.x, self.y - other.y, self.z - other.z)
    
    def __mul__(self, scalar):
        return Vector3(self.x * scalar, self.y * scalar, self.z * scalar)
    
    def normalize(self):
        length = math.sqrt(self.x**2 + self.y**2 + self.z**2)
        if length > 0:
            return Vector3(self.x/length, self.y/length, self.z/length)
        return Vector3(0, 0, 0)


class CartoonTrafficLight3D:
    """3D cartoon-style traffic light with rounded shapes"""
    
    def __init__(self, position, light_type='standard'):
        self.position = position
        self.light_type = light_type  # 'standard' or 'pedestrian'
        self.current_state = 'red'
        self.states = {'red': 0, 'yellow': 1, 'green': 2}
        self.is_flashing = False
        self.flash_cycle = 0
        
    def draw_sphere(self, radius, slices=16, stacks=16):
        """Draw a smooth cartoon sphere"""
        # Use GLU quadric helpers in a portable way
        quad = gluNewQuadric()
        gluQuadricNormals(quad, GLU_SMOOTH)
        glPushMatrix()
        gluSphere(quad, radius, slices, stacks)
        glPopMatrix()
    
    def draw_rounded_box(self, width, height, depth, radius=0.1):
        """Draw a box with rounded corners for cartoon effect"""
        glPushMatrix()
        
        # Draw main box
        glBegin(GL_QUADS)
        
        # Front face
        glNormal3f(0, 0, 1)
        glVertex3f(-width/2, -height/2, depth/2)
        glVertex3f(width/2, -height/2, depth/2)
        glVertex3f(width/2, height/2, depth/2)
        glVertex3f(-width/2, height/2, depth/2)
        
        # Back face
        glNormal3f(0, 0, -1)
        glVertex3f(-width/2, -height/2, -depth/2)
        glVertex3f(-width/2, height/2, -depth/2)
        glVertex3f(width/2, height/2, -depth/2)
        glVertex3f(width/2, -height/2, -depth/2)
        
        # Top face
        glNormal3f(0, 1, 0)
        glVertex3f(-width/2, height/2, -depth/2)
        glVertex3f(-width/2, height/2, depth/2)
        glVertex3f(width/2, height/2, depth/2)
        glVertex3f(width/2, height/2, -depth/2)
        
        # Bottom face
        glNormal3f(0, -1, 0)
        glVertex3f(-width/2, -height/2, -depth/2)
        glVertex3f(width/2, -height/2, -depth/2)
        glVertex3f(width/2, -height/2, depth/2)
        glVertex3f(-width/2, -height/2, depth/2)
        
        # Right face
        glNormal3f(1, 0, 0)
        glVertex3f(width/2, -height/2, -depth/2)
        glVertex3f(width/2, height/2, -depth/2)
        glVertex3f(width/2, height/2, depth/2)
        glVertex3f(width/2, -height/2, depth/2)
        
        # Left face
        glNormal3f(-1, 0, 0)
        glVertex3f(-width/2, -height/2, -depth/2)
        glVertex3f(-width/2, -height/2, depth/2)
        glVertex3f(-width/2, height/2, depth/2)
        glVertex3f(-width/2, height/2, -depth/2)
        
        glEnd()
        glPopMatrix()
    
    def draw_light_fixture(self):
        """Draw the main traffic light fixture"""
        glPushMatrix()
        glTranslatef(self.position.x, self.position.y, self.position.z)
        
        # Draw pole/post (dark gray)
        glColor3f(0.3, 0.3, 0.3)
        glPushMatrix()
        glScalef(0.15, 2.0, 0.15)
        self.draw_rounded_box(0.3, 1.0, 0.3, 0.05)
        glPopMatrix()
        
        # Draw main fixture box (dark gray with glossy finish)
        glColor3f(0.2, 0.2, 0.2)
        glPushMatrix()
        glTranslatef(0, 1.2, 0)
        self.draw_rounded_box(0.5, 1.8, 0.4, 0.1)
        glPopMatrix()
        
        # Draw light circles (3 for standard, 2 for pedestrian)
        light_positions = [(0, 0.9, 0.25), (0, 0.3, 0.25), (0, -0.3, 0.25)]
        if self.light_type == 'pedestrian':
            light_positions = [(0, 0.6, 0.25), (0, -0.4, 0.25)]
        
        states_list = ['red', 'yellow', 'green'] if self.light_type == 'standard' else ['walk', 'wait']
        
        for i, (x, y, z) in enumerate(light_positions):
            glPushMatrix()
            glTranslatef(x, y + 1.2, z)
            
            # Set light color based on state
            if self.light_type == 'standard':
                if i == 0:  # Red
                    if self.current_state == 'red':
                        if not self.is_flashing or self.flash_cycle < 0.5:
                            glColor3f(1.0, 0.2, 0.2)  # Bright red
                        else:
                            glColor3f(0.5, 0.1, 0.1)  # Dim red
                    else:
                        glColor3f(0.3, 0.05, 0.05)  # Dim when off
                elif i == 1:  # Yellow
                    if self.current_state == 'yellow':
                        glColor3f(1.0, 1.0, 0.2)  # Bright yellow
                    else:
                        glColor3f(0.3, 0.3, 0.05)  # Dim when off
                elif i == 2:  # Green
                    if self.current_state == 'green':
                        glColor3f(0.2, 1.0, 0.2)  # Bright green
                    else:
                        glColor3f(0.05, 0.3, 0.05)  # Dim when off
            else:  # Pedestrian
                if i == 0:  # Walk (Green)
                    if self.current_state == 'walk':
                        glColor3f(0.2, 1.0, 0.2)  # Bright green
                    else:
                        glColor3f(0.05, 0.3, 0.05)  # Dim when off
                elif i == 1:  # Wait (Red)
                    if self.current_state == 'wait':
                        if not self.is_flashing or self.flash_cycle < 0.5:
                            glColor3f(1.0, 0.2, 0.2)  # Bright red
                        else:
                            glColor3f(0.5, 0.1, 0.1)  # Dim red
                    else:
                        glColor3f(0.3, 0.05, 0.05)  # Dim when off
            
            # Draw the light sphere
            self.draw_sphere(0.25, 12, 12)
            
            # Draw glow effect for active light
            if ((self.light_type == 'standard' and i == self.states[self.current_state]) or
                (self.light_type == 'pedestrian' and self.current_state == ('walk' if i == 0 else 'wait'))):
                glColor4f(1.0, 1.0, 1.0, 0.3)
                glPushMatrix()
                glScalef(1.3, 1.3, 1.3)
                self.draw_sphere(0.25, 8, 8)
                glPopMatrix()
            
            glPopMatrix()
        
        glPopMatrix()
    
    def set_state(self, state):
        """Update light state"""
        self.current_state = state
    
    def set_flashing(self, is_flashing):
        """Set flashing state for emergency vehicles"""
        self.is_flashing = is_flashing
    
    def update(self, delta_time):
        """Update animation state"""
        if self.is_flashing:
            self.flash_cycle += delta_time
            if self.flash_cycle > 1.0:
                self.flash_cycle = 0


class Vehicle3D:
    """Simple 3D vehicle that moves along a straight path between two points."""
    def __init__(self, start: Vector3, end: Vector3, speed=3.0, color=(0.8,0.1,0.1)):
        self.start = start
        self.end = end
        self.color = color
        self.speed = speed  # units per second
        self.progress = 0.0  # 0=start, 1=end
        self.stopped = False

    def path_length(self):
        dx = self.end.x - self.start.x
        dy = self.end.y - self.start.y
        dz = self.end.z - self.start.z
        return math.sqrt(dx*dx + dy*dy + dz*dz)

    def current_pos(self):
        return Vector3(
            self.start.x + (self.end.x - self.start.x) * self.progress,
            self.start.y + (self.end.y - self.start.y) * self.progress,
            self.start.z + (self.end.z - self.start.z) * self.progress,
        )

    def update(self, delta_time, allowed=True, speed_factor=1.0):
        if self.stopped and allowed:
            self.stopped = False
        if not allowed:
            # Do not advance if not allowed; remain stopped near intersection
            self.stopped = True
            return

        # Advance progress along path
        if self.progress < 1.0 and not self.stopped:
            dist = self.path_length()
            if dist <= 0:
                return
            step = (self.speed * speed_factor) * delta_time / dist
            self.progress += step
            if self.progress > 1.0:
                self.progress = 1.0

    def draw(self):
        pos = self.current_pos()
        # Simple cuboid representation
        glPushMatrix()
        glTranslatef(pos.x, pos.y + 0.12, pos.z)
        glScalef(0.4, 0.25, 0.2)
        glColor3f(*self.color)
        glBegin(GL_QUADS)
        # front
        glVertex3f(-1, -1, 1)
        glVertex3f(1, -1, 1)
        glVertex3f(1, 1, 1)
        glVertex3f(-1, 1, 1)
        # back
        glVertex3f(-1, -1, -1)
        glVertex3f(-1, 1, -1)
        glVertex3f(1, 1, -1)
        glVertex3f(1, -1, -1)
        # left
        glVertex3f(-1, -1, -1)
        glVertex3f(-1, -1, 1)
        glVertex3f(-1, 1, 1)
        glVertex3f(-1, 1, -1)
        # right
        glVertex3f(1, -1, -1)
        glVertex3f(1, 1, -1)
        glVertex3f(1, 1, 1)
        glVertex3f(1, -1, 1)
        # top
        glVertex3f(-1, 1, -1)
        glVertex3f(-1, 1, 1)
        glVertex3f(1, 1, 1)
        glVertex3f(1, 1, -1)
        # bottom
        glVertex3f(-1, -1, -1)
        glVertex3f(1, -1, -1)
        glVertex3f(1, -1, 1)
        glVertex3f(-1, -1, 1)
        glEnd()
        glPopMatrix()


class TrafficScene3D:
    """Main 3D scene with traffic lights, pedestrians, and environment"""
    
    def __init__(self, controller=None):
        self.controller = controller
        self.traffic_lights = []
        self.pedestrian_lights = []
        self.emergency_mode = False
        # Tweak camera defaults to better frame the intersection
        self.camera_angle = 30.0
        self.camera_height = 3.0
        self.camera_distance = 8.0
        # Vehicles and spawn control
        self.vehicles = []
        self._spawn_timer = 0.0
        self._spawn_interval = 1.6  # seconds between spawns on each direction
        self.state_history = deque(maxlen=100)
        self.time_elapsed = 0
        self.frame_count = 0
        
        self._init_lights()
        logger.info("TrafficScene3D initialized")
    
    def _init_lights(self):
        """Initialize traffic lights in 3D space"""
        # Main traffic lights (North, South, East, West)
        self.traffic_lights = [
            CartoonTrafficLight3D(Vector3(-2.0, 0, 0), 'standard'),  # West
            CartoonTrafficLight3D(Vector3(2.0, 0, 0), 'standard'),   # East
            CartoonTrafficLight3D(Vector3(0, 0, -2.0), 'standard'),  # South
            CartoonTrafficLight3D(Vector3(0, 0, 2.0), 'standard'),   # North
        ]
        
        # Pedestrian lights
        self.pedestrian_lights = [
            CartoonTrafficLight3D(Vector3(-1.0, 0, -1.5), 'pedestrian'),  # SW corner
            CartoonTrafficLight3D(Vector3(1.0, 0, -1.5), 'pedestrian'),   # SE corner
            CartoonTrafficLight3D(Vector3(1.0, 0, 1.5), 'pedestrian'),    # NE corner
            CartoonTrafficLight3D(Vector3(-1.0, 0, 1.5), 'pedestrian'),   # NW corner
        ]
    
    def setup_lights(self):
        """Configure OpenGL lighting"""
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_LIGHT1)
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
        
        # Main light (sun-like)
        glLight(GL_LIGHT0, GL_POSITION, (5, 8, 5, 0))
        glLight(GL_LIGHT0, GL_AMBIENT, (0.4, 0.4, 0.4, 1))
        glLight(GL_LIGHT0, GL_DIFFUSE, (1, 1, 1, 1))
        glLight(GL_LIGHT0, GL_SPECULAR, (1, 1, 1, 1))
        
        # Fill light
        glLight(GL_LIGHT1, GL_POSITION, (-5, 3, -5, 0))
        glLight(GL_LIGHT1, GL_AMBIENT, (0.2, 0.2, 0.2, 1))
        glLight(GL_LIGHT1, GL_DIFFUSE, (0.5, 0.5, 0.5, 1))
    
    def draw_ground(self):
        """Draw the ground plane with grid"""
        glDisable(GL_LIGHTING)
        glColor3f(0.2, 0.2, 0.2)
        glBegin(GL_QUADS)
        glVertex3f(-6, -0.01, -6)
        glVertex3f(6, -0.01, -6)
        glVertex3f(6, -0.01, 6)
        glVertex3f(-6, -0.01, 6)
        glEnd()
        
        # Draw grid lines
        glColor3f(0.4, 0.4, 0.4)
        glBegin(GL_LINES)
        for i in range(-6, 7):
            glVertex3f(i, 0, -6)
            glVertex3f(i, 0, 6)
            glVertex3f(-6, 0, i)
            glVertex3f(6, 0, i)
        glEnd()
        
        glEnable(GL_LIGHTING)
    
    def draw_road(self):
        """Draw road markings"""
        glDisable(GL_LIGHTING)
        glColor3f(0.5, 0.5, 0.0)  # Yellow road markings
        glLineWidth(2.0)
        glBegin(GL_LINES)
        
        # Horizontal road lines
        for i in range(-6, 7, 2):
            glVertex3f(i, 0.01, -0.5)
            glVertex3f(i, 0.01, 0.5)
        
        # Vertical road lines
        for i in range(-6, 7, 2):
            glVertex3f(-0.5, 0.01, i)
            glVertex3f(0.5, 0.01, i)
        
        glEnd()
        glLineWidth(1.0)
        glEnable(GL_LIGHTING)

    def draw_lanes(self):
        """Draw four lanes (two directions crossing) as dark gray strips"""
        glDisable(GL_LIGHTING)
        # East-West lane
        glColor3f(0.08, 0.08, 0.08)
        glBegin(GL_QUADS)
        glVertex3f(-6, 0.005, -1.2)
        glVertex3f(6, 0.005, -1.2)
        glVertex3f(6, 0.005, -0.2)
        glVertex3f(-6, 0.005, -0.2)

        glVertex3f(-6, 0.005, 0.2)
        glVertex3f(6, 0.005, 0.2)
        glVertex3f(6, 0.005, 1.2)
        glVertex3f(-6, 0.005, 1.2)
        glEnd()

        # North-South lane
        glBegin(GL_QUADS)
        glVertex3f(-1.2, 0.005, -6)
        glVertex3f(-0.2, 0.005, -6)
        glVertex3f(-0.2, 0.005, 6)
        glVertex3f(-1.2, 0.005, 6)

        glVertex3f(0.2, 0.005, -6)
        glVertex3f(1.2, 0.005, -6)
        glVertex3f(1.2, 0.005, 6)
        glVertex3f(0.2, 0.005, 6)
        glEnd()

        # Lane dividers (dashed)
        glColor3f(1.0, 1.0, 0.0)
        glLineWidth(2.0)
        glBegin(GL_LINES)
        for i in range(-6, 7):
            # East-West center divider
            glVertex3f(i + 0.4, 0.01, 0)
            glVertex3f(i + 0.6, 0.01, 0)
            # North-South center divider
            glVertex3f(0, 0.01, i + 0.4)
            glVertex3f(0, 0.01, i + 0.6)
        glEnd()
        glLineWidth(1.0)
        glEnable(GL_LIGHTING)
    
    def draw_crosswalks(self):
        """Draw pedestrian crosswalks"""
        glDisable(GL_LIGHTING)
        glColor3f(1.0, 1.0, 1.0)  # White stripes
        glBegin(GL_QUADS)
        
        # Horizontal crosswalk
        for i in range(-5, 6):
            glVertex3f(i - 0.1, 0.01, -0.3)
            glVertex3f(i + 0.1, 0.01, -0.3)
            glVertex3f(i + 0.1, 0.01, 0.3)
            glVertex3f(i - 0.1, 0.01, 0.3)
        
        # Vertical crosswalk
        for i in range(-5, 6):
            glVertex3f(-0.3, 0.01, i - 0.1)
            glVertex3f(0.3, 0.01, i - 0.1)
            glVertex3f(0.3, 0.01, i + 0.1)
            glVertex3f(-0.3, 0.01, i + 0.1)
        
        glEnd()
        glEnable(GL_LIGHTING)
    
    def update(self, delta_time):
        """Update scene state"""
        self.time_elapsed += delta_time
        self.frame_count += 1
        
        # Update camera angle for rotation
        self.camera_angle += delta_time * 10  # Slow rotation
        if self.camera_angle > 360:
            self.camera_angle = 0
        
        # Update all lights
        for light in self.traffic_lights:
            light.update(delta_time)
        for light in self.pedestrian_lights:
            light.update(delta_time)
        
        # Sync with controller
        if self.controller:
            self._sync_with_controller()

        # Spawn vehicles periodically
        self._spawn_timer += delta_time
        if self._spawn_timer >= self._spawn_interval:
            self._spawn_timer = 0.0
            # spawn one vehicle per direction with slight random color
            colors = [(0.8,0.1,0.1), (0.1,0.1,0.8), (0.1,0.8,0.1), (0.8,0.6,0.1)]
            # West -> East (x from -6 to 6) along z = -0.6
            self.vehicles.append(Vehicle3D(Vector3(-6, 0, -0.6), Vector3(6, 0, -0.6), speed=4.0, color=random.choice(colors)))
            # East -> West
            self.vehicles.append(Vehicle3D(Vector3(6, 0, 0.6), Vector3(-6, 0, 0.6), speed=4.0, color=random.choice(colors)))
            # South -> North
            self.vehicles.append(Vehicle3D(Vector3(-0.6, 0, -6), Vector3(-0.6, 0, 6), speed=3.5, color=random.choice(colors)))
            # North -> South
            self.vehicles.append(Vehicle3D(Vector3(0.6, 0, 6), Vector3(0.6, 0, -6), speed=3.5, color=random.choice(colors)))

        # Determine which directions are allowed to move
        # We'll use the north traffic light (index 3) as the cycle controller: when north is green, north-south moves
        north_state = self.traffic_lights[3].current_state if len(self.traffic_lights) > 3 else 'red'
        north_south_allowed = (north_state == 'green')

        # Update vehicles and remove those that finished their path
        remaining = []
        for v in self.vehicles:
            # Decide allowed based on lane orientation
            # East-West lanes have z near -0.6 or 0.6; north-south lanes have x near -0.6 or 0.6
            pos = v.current_pos()
            is_east_west = abs(v.start.z) > 0.5
            allowed = north_south_allowed if not is_east_west else (not north_south_allowed)

            # If approaching intersection and light is red, stop
            # compute distance to center
            center_dist = math.sqrt(pos.x*pos.x + pos.z*pos.z)
            stop_distance = 1.2
            if center_dist < stop_distance and not allowed:
                v.update(delta_time, allowed=False)
            else:
                # yellow could be slower; check light state for some slow-down later
                speed_factor = 1.0
                if north_state == 'yellow':
                    speed_factor = 0.6
                v.update(delta_time, allowed=True, speed_factor=speed_factor)

            # keep vehicle until it reaches end
            if v.progress < 0.999:
                remaining.append(v)
        self.vehicles = remaining
    
    def _sync_with_controller(self):
        """Synchronize with backend traffic controller"""
        try:
            # Get current state from controller
            if hasattr(self.controller, 'state'):
                state = self.controller.state
                
                # Update main traffic lights
                if state.get('north_light') == 'green':
                    self.traffic_lights[3].set_state('green')
                    self.pedestrian_lights[3].set_state('wait')
                elif state.get('north_light') == 'yellow':
                    self.traffic_lights[3].set_state('yellow')
                    self.pedestrian_lights[3].set_state('wait')
                else:
                    self.traffic_lights[3].set_state('red')
                    self.pedestrian_lights[3].set_state('walk')
                
                # Check for emergency vehicles
                if state.get('ambulance_active'):
                    self.emergency_mode = True
                    for light in self.traffic_lights:
                        light.set_flashing(True)
                else:
                    self.emergency_mode = False
                    for light in self.traffic_lights:
                        light.set_flashing(False)
        except Exception as e:
            logger.debug(f"Sync error: {e}")
    
    def render(self):
        """Render the complete 3D scene"""
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        
        # Position camera with smooth rotation
        cam_x = self.camera_distance * math.cos(math.radians(self.camera_angle))
        cam_z = self.camera_distance * math.sin(math.radians(self.camera_angle))
        gluLookAt(cam_x, self.camera_height, cam_z,
                  0, 0.5, 0,
                  0, 1, 0)
        
        # Draw scene elements
        # Debug axes and origin cube to help diagnose blank renders
        try:
            self._draw_debug_axes()
        except Exception:
            logger.exception("Debug axes draw failed")

        self.draw_ground()
        # Draw lane geometry under road markings
        self.draw_lanes()
        self.draw_road()
        self.draw_crosswalks()
        # Draw vehicles on the lanes
        try:
            for v in self.vehicles:
                v.draw()
        except Exception:
            logger.exception("Vehicle draw failed")
        # Draw traffic lights
        for light in self.traffic_lights:
            light.draw_light_fixture()
        
        # Draw pedestrian lights
        for light in self.pedestrian_lights:
            light.draw_light_fixture()

    def _draw_debug_axes(self):
        """Draw RGB axes and a small cube at origin for debugging"""
        glDisable(GL_LIGHTING)
        glLineWidth(3.0)
        glBegin(GL_LINES)
        # X axis - red
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(1.5, 0, 0)
        # Y axis - green
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, 1.5, 0)
        # Z axis - blue
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, 0, 1.5)
        glEnd()

        # Small cube at origin
        glPushMatrix()
        glTranslatef(0.0, 0.0, 0.0)
        glScalef(0.2, 0.2, 0.2)
        glColor3f(0.9, 0.9, 0.2)
        glBegin(GL_QUADS)
        # front
        glVertex3f(-1, -1, 1)
        glVertex3f(1, -1, 1)
        glVertex3f(1, 1, 1)
        glVertex3f(-1, 1, 1)
        # back
        glVertex3f(-1, -1, -1)
        glVertex3f(-1, 1, -1)
        glVertex3f(1, 1, -1)
        glVertex3f(1, -1, -1)
        # left
        glVertex3f(-1, -1, -1)
        glVertex3f(-1, -1, 1)
        glVertex3f(-1, 1, 1)
        glVertex3f(-1, 1, -1)
        # right
        glVertex3f(1, -1, -1)
        glVertex3f(1, 1, -1)
        glVertex3f(1, 1, 1)
        glVertex3f(1, -1, 1)
        # top
        glVertex3f(-1, 1, -1)
        glVertex3f(-1, 1, 1)
        glVertex3f(1, 1, 1)
        glVertex3f(1, 1, -1)
        # bottom
        glVertex3f(-1, -1, -1)
        glVertex3f(1, -1, -1)
        glVertex3f(1, -1, 1)
        glVertex3f(-1, -1, 1)
        glEnd()
        glPopMatrix()
        glEnable(GL_LIGHTING)


class Animation3D:
    """Main 3D animation controller using Pygame + OpenGL"""
    
    def __init__(self, controller=None, width=1200, height=800):
        pygame.init()
        # Write a readiness file so external tooling can detect startup before Pygame window
        try:
            here = os.path.dirname(__file__)
            ready_path = os.path.join(here, 'animation_ready.txt')
            with open(ready_path, 'w', encoding='utf-8') as rf:
                rf.write(f"READY {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        except Exception:
            logger.exception('Failed to write animation_ready.txt')
        self.display = (width, height)
        self.controller = controller
        self.running = True
        self.clock = pygame.time.Clock()
        self.fps = 60
        
        # Initialize OpenGL
        pygame.display.set_mode(self.display, DOUBLEBUF | OPENGL)
        pygame.display.set_caption("🚦 3D Traffic Light Animation - Cartoon Style")
        # Create scene first so setup can reference it
        self.scene = TrafficScene3D(controller)

        # Ensure module logger writes to a file so runs are inspectable
        try:
            here = os.path.dirname(__file__)
            log_file = os.path.join(here, 'animation3d.log')
            # Add a FileHandler for this logfile if not already attached
            existing = [getattr(h, 'baseFilename', None) for h in logger.handlers if hasattr(h, 'baseFilename')]
            if os.path.abspath(log_file) not in [os.path.abspath(p) for p in existing if p]:
                fh = logging.FileHandler(log_file)
                fh.setLevel(logging.INFO)
                fh.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%H:%M:%S'))
                logger.addHandler(fh)
                logger.info(f"Animation3D logging to {log_file}")
        except Exception:
            # Non-fatal: logging setup failure should not prevent animation
            logger.exception("Failed to set up file logging for Animation3D")

        self._setup_opengl()
        
        logger.info("Animation3D initialized successfully")
    
    def _setup_opengl(self):
        """Configure OpenGL settings"""
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glClearColor(0.6, 0.8, 1.0, 1.0)  # Sky blue background
        
        # Perspective setup
        # Ensure projection matrix and viewport are set
        glViewport(0, 0, self.display[0], self.display[1])
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(45, (self.display[0] / self.display[1]), 0.1, 50.0)
        glMatrixMode(GL_MODELVIEW)
        
        self.scene.setup_lights()
    
    def handle_events(self):
        """Handle user input events"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                elif event.key == pygame.K_r:
                    # Reset camera
                    self.scene.camera_angle = 0
                elif event.key == pygame.K_UP:
                    self.scene.camera_distance -= 0.5
                elif event.key == pygame.K_DOWN:
                    self.scene.camera_distance += 0.5
    
    def run(self):
        """Main animation loop"""
        logger.info("Starting 3D animation loop")
        try:
            while self.running:
                self.handle_events()
                
                # Calculate delta time
                delta_time = self.clock.tick(self.fps) / 1000.0
                
                # Update scene
                self.scene.update(delta_time)
                
                # Render
                self.scene.render()
                
                # Display FPS
                glMatrixMode(GL_PROJECTION)
                glPushMatrix()
                glLoadIdentity()
                glOrtho(0, self.display[0], self.display[1], 0, -1, 1)
                glMatrixMode(GL_MODELVIEW)
                glPushMatrix()
                glLoadIdentity()
                glDisable(GL_LIGHTING)
                
                # Show stats
                fps_text = f"FPS: {self.clock.get_fps():.1f} | Emergency: {'YES' if self.scene.emergency_mode else 'NO'}"
                
                glEnable(GL_LIGHTING)
                glPopMatrix()
                glMatrixMode(GL_PROJECTION)
                glPopMatrix()
                glMatrixMode(GL_MODELVIEW)
                
                pygame.display.flip()
        except Exception as e:
            logger.error(f"Animation error: {e}")
        finally:
            pygame.quit()
            logger.info("Animation3D closed")
    
    def stop(self):
        """Stop the animation"""
        self.running = False


def run_3d_animation(controller=None):
    """Start the 3D animation"""
    animation = Animation3D(controller)
    animation.run()


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%H:%M:%S'
    )
    run_3d_animation()
