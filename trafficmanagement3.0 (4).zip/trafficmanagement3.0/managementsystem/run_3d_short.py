import threading
import time
import logging
import os

from backend import TrafficLightController
from animation_3d_render import Animation3D

here = os.path.dirname(__file__)
log_path = os.path.join(here, 'run_3d_short.log')
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def run_short(duration=6):
    # File logging for this short run
    fh = logging.FileHandler(log_path)
    fh.setLevel(logging.INFO)
    fh.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(fh)

    # Write a status file so external tools can see progress even if GUI swallows output
    status_path = os.path.join(here, 'run_3d_short_status.txt')
    try:
        with open(status_path, 'w', encoding='utf-8') as sf:
            sf.write(f"STARTED {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    except Exception:
        logger.exception('Failed to write status start file')

    logger.info(f"Starting 3D short run for {duration} seconds")
    controller = TrafficLightController(lambda s: None)
    # Start controller in background
    ct = threading.Thread(target=controller.run, name="ControllerThread", daemon=True)
    ct.start()

    # Create the animation and run it in the main thread (Safer for Pygame)
    logger.info("Initializing Animation3D")
    animation = Animation3D(controller, width=1000, height=700)

    # Schedule a stop after `duration` seconds
    def stop_animation():
        logger.info("Timer reached - stopping animation")
        animation.stop()

    timer = threading.Timer(duration, stop_animation)
    timer.start()

    try:
        # Run in the main thread so pygame can manage events properly
        animation.run()
    except Exception as e:
        logger.exception("Exception during animation.run(): %s", e)
    finally:
        timer.cancel()
        logger.info("Animation finished or stopped")
        try:
            with open(status_path, 'a', encoding='utf-8') as sf:
                sf.write(f"STOPPED {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        except Exception:
            logger.exception('Failed to write status stop file')


if __name__ == '__main__':
    run_short(6)
