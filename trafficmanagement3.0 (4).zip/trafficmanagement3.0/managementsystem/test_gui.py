#!/usr/bin/env python
"""Test script to verify enhanced frontend works"""
import sys
import traceback

try:
    print("Starting test...")
    from backend import TrafficLightController
    print("✓ Backend imported")
    
    from frontend import TrafficLightGUI
    print("✓ Frontend imported")
    
    import tkinter as tk
    print("✓ Tkinter imported")
    
    print("Creating root window...")
    root = tk.Tk()
    print("✓ Root window created")
    
    print("Creating controller...")
    controller = TrafficLightController(lambda state: None)
    print("✓ Controller created")
    
    print("Creating GUI...")
    gui = TrafficLightGUI(root, controller)
    print("✓ GUI created successfully!")
    
    print("\n✅ All components loaded successfully!")
    print("GUI window should be visible now...")
    
    # Close immediately for testing
    root.destroy()
    print("✓ Test completed successfully")
    
except Exception as e:
    print(f"\n❌ ERROR: {e}")
    traceback.print_exc()
    sys.exit(1)
