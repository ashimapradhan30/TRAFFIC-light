# 3D Animation Installation & Setup Guide

## Quick Start

### Step 1: Install Dependencies
```bash
# Install pygame for graphics
pip install pygame

# Install PyOpenGL for 3D rendering
pip install PyOpenGL PyOpenGL_accelerate
```

### Step 2: Run the Application
```bash
cd f:\trafficmanagement3.0\managementsystem
python main.py
```

### Step 3: Select 3D Mode
- When the launcher appears, select "3D Cartoon Animation"
- Click "▶ Launch Selected Mode"

## System Requirements

### Minimum Requirements
- Python 3.8+
- 4GB RAM
- OpenGL 2.0 capable GPU
- 1024x768 minimum display resolution

### Recommended Requirements
- Python 3.10+
- 8GB RAM
- OpenGL 3.3+ capable GPU
- 1920x1080+ display resolution
- Dedicated graphics card (NVIDIA, AMD, Intel HD Graphics)

## Detailed Installation

### Windows Installation

#### Using pip (Recommended)
```bash
# Open Command Prompt or PowerShell
# Navigate to project folder
cd f:\trafficmanagement3.0\managementsystem

# Install all dependencies at once
pip install pygame PyOpenGL PyOpenGL_accelerate

# Verify installation
python -c "import pygame; import OpenGL; print('✓ All dependencies installed')"
```

#### Manual Installation Steps

1. **Ensure Python is in PATH**
   - Open Command Prompt
   - Type: `python --version`
   - Should show Python 3.8 or higher

2. **Upgrade pip**
   ```bash
   python -m pip install --upgrade pip
   ```

3. **Install Pygame**
   ```bash
   pip install pygame
   
   # Verify
   python -c "import pygame; print(pygame.version.ver)"
   ```

4. **Install PyOpenGL**
   ```bash
   pip install PyOpenGL
   pip install PyOpenGL_accelerate
   
   # Verify
   python -c "from OpenGL.GL import *; print('✓ OpenGL ready')"
   ```

### macOS Installation

```bash
# Using Homebrew (recommended)
brew install python3 sdl2

# Install Python packages
pip3 install pygame PyOpenGL PyOpenGL_accelerate

# Run application
python3 main.py
```

### Linux Installation (Ubuntu/Debian)

```bash
# Install system dependencies
sudo apt-get update
sudo apt-get install python3-pip libsdl2-dev libgl1-mesa-dev

# Install Python packages
pip install pygame PyOpenGL PyOpenGL_accelerate

# Run application
python main.py
```

### Linux Installation (Fedora/RHEL)

```bash
# Install system dependencies
sudo dnf install python3-pip SDL2-devel mesa-libGL-devel

# Install Python packages
pip install pygame PyOpenGL PyOpenGL_accelerate

# Run application
python main.py
```

## Troubleshooting

### Issue: "No module named 'pygame'"

**Solution 1: Verify pip is using correct Python**
```bash
which pip                    # Shows pip location
python -m pip --version     # Verify Python version
python -m pip install pygame  # Use python -m pip instead
```

**Solution 2: Use pip3 specifically**
```bash
pip3 install pygame
```

**Solution 3: Check Python path**
```bash
python -c "import sys; print(sys.executable)"  # Shows Python path
```

### Issue: "No module named 'OpenGL'"

```bash
# Ensure both packages are installed
pip install PyOpenGL
pip install PyOpenGL_accelerate

# Force reinstall
pip install --upgrade --force-reinstall PyOpenGL
```

### Issue: "ImportError: DLL load failed"

This usually means GPU drivers are missing or outdated.

**Solution for Windows:**
1. Right-click Start Menu → Device Manager
2. Expand "Display adapters"
3. Right-click your GPU → Update driver
4. Choose "Search automatically for updated driver software"
5. Restart computer

**Solution for Linux:**
```bash
# For NVIDIA
sudo apt-get install nvidia-driver-XXX  # Replace XXX with your GPU series

# For AMD
sudo apt-get install amdgpu-dkms

# Update
sudo update-grub && sudo reboot
```

### Issue: "pygame.error: No available video device"

This occurs when running headless (no display).

**Solution for WSL/Remote:**
```bash
# Set display variable (for WSL)
export DISPLAY=:0

# Or use VcXsrv/Xming for X11 forwarding
```

### Issue: Low FPS or Stuttering

1. **Close background applications** consuming GPU memory
2. **Update GPU drivers** to latest version
3. **Reduce resolution** if GPU is too old
4. **Check system temperature** (overheating can reduce clock speed)

### Issue: Window Won't Open

1. **Check GPU support**: `python -c "from OpenGL.GL import *; glGetString(GL_VERSION)"`
2. **Verify display settings**: Try running at lower resolution
3. **Update graphics drivers**

### Issue: Application Crashes Immediately

```bash
# Run with verbose output
python -u main.py

# Check error messages and note them
```

## Verification

### Test Basic Installation
```bash
python -c "
import pygame
import OpenGL
from OpenGL.GL import *
print('✓ Pygame version:', pygame.version.ver)
print('✓ OpenGL available')
print('✓ All dependencies ready!')
"
```

### Test 3D Animation Module
```bash
cd f:\trafficmanagement3.0\managementsystem
python -c "from animation_3d_render import Animation3D; print('✓ 3D animation module ready')"
```

### Test Complete System
```bash
cd f:\trafficmanagement3.0\managementsystem
python main.py

# Select "3D Cartoon Animation" and click launch
# You should see a 3D window appear with traffic lights
```

## Performance Optimization

### For Low-End Systems

1. **Reduce polygon count** in `animation_3d_render.py`:
   ```python
   # Change in CartoonTrafficLight3D.draw_light_fixture()
   self.draw_sphere(0.25, 8, 8)   # Lower from 12, 12
   ```

2. **Reduce grid density** in `TrafficScene3D.draw_road()`:
   ```python
   # Change grid step from 2 to 4
   for i in range(-6, 7, 4):  # Was range(-6, 7, 2)
   ```

3. **Disable glow effects**:
   ```python
   # Comment out glow rendering in draw_light_fixture()
   # if ((self.light_type == 'standard' ...):
   #     glColor4f(...)
   ```

### For High-End Systems

1. **Increase polygon count**:
   ```python
   self.draw_sphere(0.25, 24, 24)  # More detailed spheres
   ```

2. **Add more road detail**:
   ```python
   for i in range(-6, 7, 1):  # Denser grid
   ```

3. **Enable advanced lighting**:
   ```python
   # Add more light sources or increase intensity values
   glLight(GL_LIGHT0, GL_DIFFUSE, (1.5, 1.5, 1.5, 1))
   ```

## GPU-Specific Notes

### NVIDIA Graphics
- **Best supported**: Kepler (GeForce 750+) and newer
- **Drivers**: Download from nvidia.com
- **CUDA acceleration**: Optional but recommended

### AMD Graphics
- **Best supported**: GCN architecture (R9 290+)
- **Drivers**: Download from amd.com
- **ROCm support**: Advanced alternative

### Intel Integrated Graphics
- **Best supported**: Intel HD Graphics 620 and newer
- **Drivers**: Update through Device Manager (Windows) or distro manager (Linux)
- **Performance**: Will run but at lower FPS on complex scenes

### macOS (Apple Silicon)
- **M1/M2/M3**: Full support through Metal (via MoltenGL)
- **Intel Macs**: Standard OpenGL support
- **Note**: Older PyOpenGL may have compatibility issues

## Environment Variables

Optional environment variables for advanced configuration:

```bash
# Linux: Force software rendering if GPU causes issues
export LIBGL_ALWAYS_INDIRECT=1

# Linux: Use specific OpenGL implementation
export MESA_GL_VERSION_OVERRIDE=3.3

# Windows: Debug output (limited support)
set LIBGL_DEBUG=all
```

## Getting Help

### Create Diagnostic Report
```bash
python diagnostics.py > diagnostic_report.txt

# Then review diagnostic_report.txt for detailed system info
```

### Common Patterns

If you get errors, check these in order:
1. Python version: `python --version` (should be 3.8+)
2. pip location: `which pip` or `where pip`
3. Package versions: `pip list | findstr pygame`
4. GPU driver: Device Manager (Windows) or `glxinfo` (Linux)
5. OpenGL version: `glxinfo | grep "OpenGL version"` (Linux)

## Installation Checklist

- [ ] Python 3.8+ installed
- [ ] pip is current: `python -m pip install --upgrade pip`
- [ ] pygame installed: `pip install pygame`
- [ ] PyOpenGL installed: `pip install PyOpenGL PyOpenGL_accelerate`
- [ ] Dependencies verified: `python -c "import pygame; import OpenGL; print('OK')"`
- [ ] 3D animation tested: `python animation_3d_render.py` (or via launcher)
- [ ] GPU drivers updated to latest version
- [ ] Display resolution at least 1024x768

## Next Steps

Once installed successfully:
1. Review `3D_ANIMATION_GUIDE.md` for feature details
2. Run `python main.py` and select 3D mode
3. Use arrow keys and 'R' key for camera controls
4. Monitor FPS in top-left corner
5. Check ambulance priority flashing effect (press space in 2D mode to trigger)

## Support Resources

- **Pygame Documentation**: https://www.pygame.org/docs/
- **PyOpenGL Documentation**: http://PyOpenGL.sourceforge.net/documentation/
- **OpenGL Tutorial**: https://learnopengl.com/
- **Python Documentation**: https://docs.python.org/3/

---

**Installation Complete!** Enjoy the 3D Traffic Light Animation! 🚦
