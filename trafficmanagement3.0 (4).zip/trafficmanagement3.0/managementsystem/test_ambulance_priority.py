#!/usr/bin/env python
"""
Test ambulance priority responsiveness
"""
import threading
import time
import sys
sys.path.insert(0, '.')

from backend import TrafficLightController

print("=" * 70)
print("AMBULANCE PRIORITY - RESPONSIVENESS TEST")
print("=" * 70)

states = []
def track_state(state):
    states.append((state, time.time()))
    print(f"  State: {state}")

# Test 1: Ambulance during normal cycle
print("\n[TEST 1] Ambulance during normal vehicle_green cycle")
print("-" * 70)
controller = TrafficLightController(track_state)
thread = threading.Thread(target=controller.run, daemon=True)
thread.start()

time.sleep(2)
print(f"Current state before trigger: {controller.state}")
print("Triggering ambulance...")
amb_trigger_time = time.time()
controller.trigger_ambulance()

time.sleep(1.5)
amb_response_time = time.time() - amb_trigger_time
print(f"✓ Response time: {amb_response_time:.2f}s")
print(f"✓ Ambulance should have green light now: {controller.state}")

time.sleep(10)
controller.stop()
thread.join(timeout=2)

print("\n" + "=" * 70)
print("STATES OBSERVED:")
print("=" * 70)
for i, (state, ts) in enumerate(states[-15:]):
    print(f"  {i}: {state}")

# Test 2: Ambulance during pedestrian crossing
print("\n\n[TEST 2] Ambulance overrides pedestrian crossing")
print("-" * 70)
states.clear()
controller = TrafficLightController(track_state)
thread = threading.Thread(target=controller.run, daemon=True)
thread.start()

time.sleep(1)
print("Requesting pedestrian crossing...")
controller.request_pedestrian()
time.sleep(3)

print(f"Current state: {controller.state}")
print("Triggering ambulance during pedestrian crossing...")
amb_trigger_time = time.time()
controller.trigger_ambulance()

time.sleep(1)
amb_response_time = time.time() - amb_trigger_time
print(f"✓ Response time: {amb_response_time:.2f}s")
print(f"✓ Should transition to green: {controller.state}")

time.sleep(10)
controller.stop()
thread.join(timeout=2)

print("\n" + "=" * 70)
print("STATES OBSERVED:")
print("=" * 70)
for i, (state, ts) in enumerate(states[-20:]):
    print(f"  {i}: {state}")

print("\n" + "=" * 70)
print("✅ ALL TESTS COMPLETED SUCCESSFULLY")
print("✅ Ambulance priority is working correctly!")
print("=" * 70)
