# 3D Animation - Setup and Run

This project includes a 3D cartoon-style traffic animation using `pygame` + `PyOpenGL`.

Prerequisites
- Python 3.8+
- Install dependencies (recommended in virtualenv):

```powershell
python -m pip install -r requirements.txt
```

Run the full app (will prefer 3D if available):

```powershell
python -m managementsystem.main
```

Force 3D mode or 2D mode explicitly:

```powershell
python -m managementsystem.main --mode 3d
python -m managementsystem.main --mode 2d
```

Short 3D test (opens window for ~6 seconds and logs to `run_3d_short.log`):

```powershell
python run_3d_short.py
```

Troubleshooting
- If 3D fails to start, ensure you have `pygame` and `PyOpenGL` installed.
- On Windows, use a compatible GPU driver. If a headless environment is used, 3D will not run.

If you want, I can also add a CLI flag to log all 3D output to a specified file automatically.
