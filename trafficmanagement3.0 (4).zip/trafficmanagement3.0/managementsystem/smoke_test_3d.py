"""
Non-graphical smoke test for 3D animation module.
This test constructs scene objects and exercises controller sync
without creating a Pygame/OpenGL window.
"""
import logging
from animation_3d_render import TrafficScene3D, CartoonTrafficLight3D, Vector3

logging.basicConfig(level=logging.INFO, format='%(H:%M:%S)s - %(levelname)s - %(message)s')


class DummyController:
    def __init__(self):
        # Minimal shape the scene expects
        self.state = {
            'north_light': 'red',
            'ambulance_active': False
        }


def main():
    print("Starting non-graphical 3D smoke test...")
    ctrl = DummyController()

    # Instantiate scene (does not call OpenGL functions in constructor)
    scene = TrafficScene3D(controller=ctrl)
    print(f"Scene created: {len(scene.traffic_lights)} traffic lights, {len(scene.pedestrian_lights)} pedestrian lights")

    # Initial sync should set lights according to controller.state
    scene._sync_with_controller()
    north_state = scene.traffic_lights[3].current_state
    print(f"Initial north light state: {north_state}")

    # Mutate controller state to simulate a green phase and ambulance activation
    ctrl.state['north_light'] = 'green'
    ctrl.state['ambulance_active'] = True
    scene._sync_with_controller()

    north_state_after = scene.traffic_lights[3].current_state
    print(f"After update north light state: {north_state_after}")
    print(f"Scene emergency_mode flag: {scene.emergency_mode}")

    # Verify flashing flags propagated
    flashing_flags = [tl.is_flashing for tl in scene.traffic_lights]
    print(f"Traffic lights flashing flags: {flashing_flags}")

    # Call update() to advance timing logic
    scene.update(0.16)
    print(f"Time elapsed after update: {scene.time_elapsed:.3f}, frame_count: {scene.frame_count}")

    print("Non-graphical smoke test completed successfully")


if __name__ == '__main__':
    main()
