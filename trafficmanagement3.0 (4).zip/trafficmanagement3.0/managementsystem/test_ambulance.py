#!/usr/bin/env python
"""
Test script to verify ambulance priority works without lag.
This simulates triggering ambulance while the controller is in different states.
"""

import threading
import time
import logging
from backend import TrafficLightController

# Configure logging to see all messages
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

class StateTracker:
    def __init__(self):
        self.states = []
        self.timestamps = []
    
    def track(self, state):
        self.states.append(state)
        self.timestamps.append(time.time())
        logger.info(f"State change: {state}")

def test_ambulance_during_green():
    """Test: Trigger ambulance while in vehicle_green state"""
    logger.info("\n" + "="*60)
    logger.info("TEST 1: Ambulance during Vehicle Green")
    logger.info("="*60)
    
    tracker = StateTracker()
    controller = TrafficLightController(tracker.track)
    
    # Start controller in a background thread
    thread = threading.Thread(target=controller.run, daemon=True)
    thread.start()
    
    # Let it run in normal cycle for a bit
    time.sleep(2)
    
    logger.info("Triggering ambulance NOW...")
    start_time = time.time()
    controller.trigger_ambulance()
    
    # Wait for ambulance sequence to complete
    time.sleep(12)
    
    elapsed = time.time() - start_time
    logger.info(f"✓ Ambulance test completed in {elapsed:.1f}s")
    logger.info(f"  States observed: {' → '.join(tracker.states[-10:])}")
    
    controller.stop()
    thread.join(timeout=2)
    return True

def test_ambulance_during_red():
    """Test: Trigger ambulance while in vehicle_red state"""
    logger.info("\n" + "="*60)
    logger.info("TEST 2: Ambulance during Vehicle Red (longest wait)")
    logger.info("="*60)
    
    tracker = StateTracker()
    controller = TrafficLightController(tracker.track)
    
    # Start controller in a background thread
    thread = threading.Thread(target=controller.run, daemon=True)
    thread.start()
    
    # Let it run until we get to red (yellow=5s, then yellow=2s, then red=1s = ~8s)
    time.sleep(9)
    
    logger.info(f"Current state: {controller.state}")
    logger.info("Triggering ambulance NOW...")
    start_time = time.time()
    controller.trigger_ambulance()
    
    # The ambulance sequence should override the current delay
    # This is where the lag bug would show: if it waits 1 second for red to finish,
    # the response time would be > 1 second
    time.sleep(12)
    
    elapsed = time.time() - start_time
    logger.info(f"✓ Ambulance test completed in {elapsed:.1f}s")
    logger.info(f"  Response should be < 1.1s (red duration). Actual: {elapsed:.1f}s")
    logger.info(f"  States observed: {' → '.join(tracker.states[-10:])}")
    
    controller.stop()
    thread.join(timeout=2)
    return elapsed < 1.1

def test_ambulance_during_pedestrian():
    """Test: Trigger ambulance while pedestrian crossing is active"""
    logger.info("\n" + "="*60)
    logger.info("TEST 3: Ambulance during Pedestrian Crossing")
    logger.info("="*60)
    
    tracker = StateTracker()
    controller = TrafficLightController(tracker.track)
    
    # Start controller in a background thread
    thread = threading.Thread(target=controller.run, daemon=True)
    thread.start()
    
    # Trigger pedestrian crossing
    time.sleep(2)
    logger.info("Requesting pedestrian crossing...")
    controller.request_pedestrian()
    
    # Wait a bit, then trigger ambulance during pedestrian crossing
    time.sleep(3)
    logger.info(f"Current state: {controller.state}")
    logger.info("Triggering ambulance during pedestrian crossing...")
    start_time = time.time()
    controller.trigger_ambulance()
    
    time.sleep(12)
    
    elapsed = time.time() - start_time
    logger.info(f"✓ Ambulance test completed in {elapsed:.1f}s")
    logger.info(f"  States observed: {' → '.join(tracker.states[-15:])}")
    
    controller.stop()
    thread.join(timeout=2)
    return True

def test_rapid_ambulance_triggers():
    """Test: Multiple rapid ambulance triggers"""
    logger.info("\n" + "="*60)
    logger.info("TEST 4: Rapid Ambulance Triggers")
    logger.info("="*60)
    
    tracker = StateTracker()
    controller = TrafficLightController(tracker.track)
    
    thread = threading.Thread(target=controller.run, daemon=True)
    thread.start()
    
    time.sleep(2)
    
    for i in range(3):
        logger.info(f"Trigger #{i+1}")
        controller.trigger_ambulance()
        time.sleep(4)
    
    logger.info("✓ Rapid trigger test completed")
    logger.info(f"  States observed: {' → '.join(tracker.states[-20:])}")
    
    controller.stop()
    thread.join(timeout=2)
    return True

if __name__ == "__main__":
    logger.info("🚦 Traffic Light Controller - Ambulance Priority Tests")
    logger.info("Testing that ambulance priority triggers instantly without lag")
    
    try:
        results = []
        results.append(("Ambulance during Green", test_ambulance_during_green()))
        results.append(("Ambulance during Red", test_ambulance_during_red()))
        results.append(("Ambulance during Pedestrian", test_ambulance_during_pedestrian()))
        results.append(("Rapid Triggers", test_rapid_ambulance_triggers()))
        
        logger.info("\n" + "="*60)
        logger.info("TEST SUMMARY")
        logger.info("="*60)
        for test_name, result in results:
            status = "✓ PASS" if result else "✗ FAIL"
            logger.info(f"{status}: {test_name}")
        
        logger.info("\n🎉 All tests completed!")
        
    except Exception as e:
        logger.error(f"Test error: {e}", exc_info=True)
