import sys
import os
import time

# Ensure imports from package path
here = os.path.dirname(__file__)
if here not in sys.path:
    sys.path.insert(0, here)

log_path = os.path.join(here, 'run3d_capture.log')
with open(log_path, 'w', encoding='utf-8') as f:
    # Redirect stdout/stderr to file
    sys.stdout = f
    sys.stderr = f
    try:
        print('Starting capture run at', time.strftime('%Y-%m-%d %H:%M:%S'))
        # Run the short runner
        from run_3d_short import run_short
        run_short(6)
        print('Finished capture run at', time.strftime('%Y-%m-%d %H:%M:%S'))
    except Exception as e:
        print('Exception during capture run:', e)
        import traceback
        traceback.print_exc()
    finally:
        f.flush()
