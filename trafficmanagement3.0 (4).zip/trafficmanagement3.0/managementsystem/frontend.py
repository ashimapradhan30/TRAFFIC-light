import tkinter as tk
import time
import math
import logging

logger = logging.getLogger(__name__)

class TrafficLightGUI:
    def __init__(self, root, controller):
        self.root = root
        self.controller = controller

        self.root.title("🚦 Traffic Light Management System v3.0 - Advanced Animation")
        self.root.geometry("900x750")
        self.root.configure(bg="#0d0d0d")

        # Main intersection canvas (larger for lane visualization)
        self.canvas = tk.Canvas(self.root, width=700, height=550, bg="#1a1a1a", highlightthickness=0)
        self.canvas.place(x=10, y=10)

        # Animation state tracking
        self.animation_time = 0
        self.pulse_intensity = 0
        
        # Draw intersection grid (roads)
        self._draw_intersection()
        
        # Create traffic lights for each direction with lanes
        self._create_direction_lights()
        
        # Create pedestrian signals
        self._create_pedestrian_signals()

        self.car_pos = 10
        self.ped_pos = 10
        self.amb_pos = 10

        self.ped_button = tk.Button(self.root, text="🚶 Pedestrian Request", bg="#0D6EFD", fg="white",
                                    font=("Arial", 11, "bold"), command=self.on_pedestrian)
        self.ped_button.place(x=30, y=570, width=150, height=40)

        self.ambulance_button = tk.Button(self.root, text="🚑 Ambulance Priority", bg="#dc3545", fg="white",
                                          font=("Arial", 11, "bold"), command=self.on_ambulance)
        self.ambulance_button.place(x=195, y=570, width=150, height=40)

        self.status_label = tk.Label(self.root, text="Status: Vehicle Green ✓", font=("Arial", 13, "bold"),
                                    bg="#0d0d0d", fg="#28a745")
        self.status_label.place(x=20, y=570)
        
        # Add timer display
        self.timer_label = tk.Label(self.root, text="Time: 0s", font=("Arial", 10, "bold"),
                                   bg="#0d0d0d", fg="#00FFFF")
        self.timer_label.place(x=370, y=570)
        
        # Add stats display
        self.stats_label = tk.Label(self.root, text="Vehicles: 12 | Ambulances: 3", font=("Arial", 9),
                                   bg="#0d0d0d", fg="#FF00FF")
        self.stats_label.place(x=550, y=570)

        self.animate()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        logger.info("TrafficLightGUI initialized with advanced animations")
        self.animation_frame = 0

    def _draw_intersection(self):
        """Draw the intersection with roads from all four directions"""
        # Road dimensions
        self.road_width = 70
        intersection_size = 220
        self.center_x = 350
        self.center_y = 275
        
        # Draw gradient background for roads
        self.canvas.create_rectangle(0, self.center_y - self.road_width//2, 700, self.center_y + self.road_width//2, 
                                     fill="#404040", outline="#666666", width=2)
        self.canvas.create_rectangle(self.center_x - self.road_width//2, 0, self.center_x + self.road_width//2, 550, 
                                     fill="#404040", outline="#666666", width=2)
        
        # Draw intersection center with gradient effect
        self.canvas.create_rectangle(self.center_x - intersection_size//2, self.center_y - intersection_size//2,
                                     self.center_x + intersection_size//2, self.center_y + intersection_size//2,
                                     fill="#2a2a2a", outline="#555555", width=3)
        
        # Draw detailed lane markings
        for i in range(50, 700, 50):
            self.canvas.create_line(i, self.center_y - self.road_width//2 + 3, i, self.center_y - self.road_width//2 - 3, 
                                   fill="#888888", width=2)
            self.canvas.create_line(i, self.center_y + self.road_width//2 + 3, i, self.center_y + self.road_width//2 - 3, 
                                   fill="#888888", width=2)
        
        for i in range(50, 550, 50):
            self.canvas.create_line(self.center_x - self.road_width//2 + 3, i, self.center_x - self.road_width//2 - 3, i, 
                                   fill="#888888", width=2)
            self.canvas.create_line(self.center_x + self.road_width//2 + 3, i, self.center_x + self.road_width//2 - 3, i, 
                                   fill="#888888", width=2)
        
        # Store center coordinates for later use - already done above


    def _create_pedestrian_signals(self):
        """Create pedestrian walk/don't walk signals"""
        self.pedestrian_lights = {}
        
        # Pedestrian signals at each corner
        ped_configs = {
            'north': {'x': self.center_x - 40, 'y': 30},
            'south': {'x': self.center_x + 40, 'y': 510},
            'east': {'x': 660, 'y': self.center_y - 40},
            'west': {'x': 40, 'y': self.center_y + 40},
        }
        
        for direction, config in ped_configs.items():
            x, y = config['x'], config['y']
            
            # Pedestrian walk signal (green walking figure)
            self.pedestrian_lights[direction] = {
                'walk': self.canvas.create_text(x, y, text="🚶", font=("Arial", 20), fill="darkgray"),
                'wait': self.canvas.create_text(x, y+30, text="⏸", font=("Arial", 18), fill="darkred"),
            }

    def _create_direction_lights(self):
        """Create traffic lights for each direction with enhanced visuals"""
        center_x = self.center_x
        center_y = self.center_y
        
        # Traffic light positions for each direction
        light_configs = {
            'north': {'x': center_x, 'y': 50, 'direction': 'north'},
            'south': {'x': center_x, 'y': 480, 'direction': 'south'},
            'east': {'x': 650, 'y': center_y, 'direction': 'east'},
            'west': {'x': 50, 'y': center_y, 'direction': 'west'}
        }
        
        self.direction_lights = {}
        
        for direction, config in light_configs.items():
            x, y = config['x'], config['y']
            
            # Create light objects for each direction
            self.direction_lights[direction] = {
                'red': self.canvas.create_oval(x-15, y-15, x-5, y-5, fill="darkred", outline="#333"),
                'yellow': self.canvas.create_oval(x-5, y-15, x+5, y-5, fill="darkgoldenrod", outline="#333"),
                'green': self.canvas.create_oval(x+5, y-15, x+15, y-5, fill="darkgreen", outline="#333"),
            }
        
        # Create vehicle representatives on roads - MULTIPLE VEHICLES
        self.vehicles = {}
        self.vehicle_data = {}
        
        # North direction - 3 vehicles
        vehicle_positions_north = [
            (center_x - 5, 80, center_x + 5, 95),
            (center_x - 5, 110, center_x + 5, 125),
            (center_x - 5, 140, center_x + 5, 155),
        ]
        for i, pos in enumerate(vehicle_positions_north):
            vehicle_id = self.canvas.create_rectangle(*pos, fill="#0099FF", outline="#00FF00", width=2)
            self.vehicles[f'north_{i}'] = vehicle_id
            self.vehicle_data[f'north_{i}'] = {'start_pos': pos, 'speed': 1.5}
        
        # South direction - 3 vehicles
        vehicle_positions_south = [
            (center_x - 5, 380, center_x + 5, 395),
            (center_x - 5, 410, center_x + 5, 425),
            (center_x - 5, 440, center_x + 5, 455),
        ]
        for i, pos in enumerate(vehicle_positions_south):
            vehicle_id = self.canvas.create_rectangle(*pos, fill="#0099FF", outline="#00FF00", width=2)
            self.vehicles[f'south_{i}'] = vehicle_id
            self.vehicle_data[f'south_{i}'] = {'start_pos': pos, 'speed': 1.5}
        
        # East direction - 3 vehicles
        vehicle_positions_east = [
            (430, center_y - 5, 445, center_y + 5),
            (460, center_y - 5, 475, center_y + 5),
            (490, center_y - 5, 505, center_y + 5),
        ]
        for i, pos in enumerate(vehicle_positions_east):
            vehicle_id = self.canvas.create_rectangle(*pos, fill="#FF9900", outline="#FF00FF", width=2)
            self.vehicles[f'east_{i}'] = vehicle_id
            self.vehicle_data[f'east_{i}'] = {'start_pos': pos, 'speed': 1.5}
        
        # West direction - 3 vehicles
        vehicle_positions_west = [
            (110, center_y - 5, 125, center_y + 5),
            (80, center_y - 5, 95, center_y + 5),
            (50, center_y - 5, 65, center_y + 5),
        ]
        for i, pos in enumerate(vehicle_positions_west):
            vehicle_id = self.canvas.create_rectangle(*pos, fill="#FF9900", outline="#FF00FF", width=2)
            self.vehicles[f'west_{i}'] = vehicle_id
            self.vehicle_data[f'west_{i}'] = {'start_pos': pos, 'speed': 1.5}
        
        # Create multiple AMBULANCES
        self.ambulances = {}
        self.ambulance_positions = {
            'main': (center_x - 12, center_y - 12, center_x + 12, center_y + 12),
            'backup1': (center_x - 8, center_y + 60, center_x + 8, center_y + 80),
            'backup2': (center_x + 60, center_y - 12, center_x + 80, center_y + 12),
        }
        
        for amb_name, pos in self.ambulance_positions.items():
            amb_id = self.canvas.create_rectangle(*pos, fill="white", outline="red", width=2)
            self.ambulances[amb_name] = amb_id
        
        # Track vehicle animation offset
        self.vehicle_offset = {key: 0 for key in self.vehicles.keys()}

    def update_gui(self, state):
        try:
            if state == 'vehicle_green':
                self.status_label.config(text="Status: Vehicle Green ✓", fg="#28a745")
            elif state == 'vehicle_yellow':
                self.status_label.config(text="Status: Vehicle Yellow ⚠", fg="#ffc107")
            elif state == 'vehicle_red':
                self.status_label.config(text="Status: Vehicle Red ⛔", fg="#dc3545")
            elif state == 'pedestrian_green':
                self.status_label.config(text="Status: Pedestrian Crossing 🚶", fg="#28a745")
            
            logger.debug(f"GUI updated: {state}")
        except Exception as e:
            logger.error(f"Error updating GUI: {e}")

    def on_pedestrian(self):
        logger.info("Pedestrian button clicked")
        self.controller.request_pedestrian()

    def on_ambulance(self):
        logger.warning("🚑 Ambulance button clicked")
        self.controller.trigger_ambulance()

    def animate(self):
        # Update traffic lights based on current state
        self._update_direction_lights()
        
        # Animate vehicles
        state = self.controller.state
        
        # Update all vehicles on each road
        for vehicle_key in self.vehicles.keys():
            direction = vehicle_key.split('_')[0]
            
            # Move vehicles based on traffic state
            if state == 'vehicle_green' and direction == 'north':
                # North vehicles move
                self.vehicle_offset[vehicle_key] += 1.5
                self.canvas.itemconfig(self.vehicles[vehicle_key], fill="#00FF66")  # Bright green
            elif state == 'vehicle_green' and direction == 'south':
                # South vehicles move
                self.vehicle_offset[vehicle_key] += 1.5
                self.canvas.itemconfig(self.vehicles[vehicle_key], fill="#00FF66")  # Bright green
            elif state == 'vehicle_yellow':
                self.canvas.itemconfig(self.vehicles[vehicle_key], fill="#FFAA00")  # Yellow
            elif state == 'vehicle_red':
                self.canvas.itemconfig(self.vehicles[vehicle_key], fill="#FF4444")  # Red
                self.vehicle_offset[vehicle_key] = 0  # Reset animation
            elif state == 'pedestrian_green':
                self.canvas.itemconfig(self.vehicles[vehicle_key], fill="#FF4444")  # Red
                self.vehicle_offset[vehicle_key] = 0  # Reset animation
            else:
                self.canvas.itemconfig(self.vehicles[vehicle_key], fill="#0099FF")  # Normal blue
        
        # Animate ambulances - flashing effect
        if self.controller.ambulance_priority:
            flash = int(time.time() * 10) % 2
            amb_color = "red" if flash == 0 else "white"
            amb_outline = "darkred" if flash == 0 else "yellow"
            amb_width = 3
            
            for amb_name in self.ambulances.keys():
                self.canvas.itemconfig(self.ambulances[amb_name], fill=amb_color, 
                                      outline=amb_outline, width=amb_width)
        else:
            for amb_name in self.ambulances.keys():
                self.canvas.itemconfig(self.ambulances[amb_name], fill="white", 
                                      outline="gray", width=1)
        
        self.root.after(100, self.animate)

    def _update_direction_lights(self):
        """Update traffic lights for all directions based on current state"""
        state = self.controller.state
        
        # Define which directions are active for each state
        if state == 'vehicle_green':
            # North-South gets green (main direction)
            green_dirs = ['north', 'south']
            red_dirs = ['east', 'west']
            yellow_dirs = []
        elif state == 'vehicle_yellow':
            # All directions yellow
            green_dirs = []
            red_dirs = []
            yellow_dirs = ['north', 'south', 'east', 'west']
        elif state == 'vehicle_red':
            # All directions red
            green_dirs = []
            red_dirs = ['north', 'south', 'east', 'west']
            yellow_dirs = []
        elif state == 'pedestrian_green':
            # All vehicles red during pedestrian crossing
            green_dirs = []
            red_dirs = ['north', 'south', 'east', 'west']
            yellow_dirs = []
        else:
            green_dirs = []
            red_dirs = ['north', 'south', 'east', 'west']
            yellow_dirs = []
        
        # Apply glow effect using pulse
        pulse = int((math.sin(time.time() * 5) + 1) * 50)
        
        def get_color(base_color, active):
            if not active:
                return "dark" + base_color if base_color != "yellow" else "darkgoldenrod"
            if base_color == "red":
                return f"#{pulse + 155:02x}0000"
            elif base_color == "yellow":
                return f"#{pulse + 155:02x}{pulse + 155:02x}00"
            elif base_color == "green":
                return f"#00{pulse + 155:02x}00"
            return "gray"
        
        # Update all direction lights
        for direction in ['north', 'south', 'east', 'west']:
            lights = self.direction_lights[direction]
            
            is_red = direction in red_dirs
            is_yellow = direction in yellow_dirs
            is_green = direction in green_dirs
            
            self.canvas.itemconfig(lights['red'], fill=get_color('red', is_red))
            self.canvas.itemconfig(lights['yellow'], fill=get_color('yellow', is_yellow))
            self.canvas.itemconfig(lights['green'], fill=get_color('green', is_green))

    def on_close(self):
        logger.info("Closing application")
        self.controller.stop()
        self.root.destroy()
